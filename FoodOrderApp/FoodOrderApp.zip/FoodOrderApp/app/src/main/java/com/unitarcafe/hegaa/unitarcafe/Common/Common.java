package com.unitarcafe.hegaa.unitarcafe.Common;

import com.unitarcafe.hegaa.unitarcafe.Model.User;

public class Common {
    public static User currentUser;
}
